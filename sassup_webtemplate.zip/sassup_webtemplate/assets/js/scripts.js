$(document).ready(function(){


    // Mobile Menu

    //  $(window).click(function () {
    //      $('.mobile-menu').removeClass('h-class');
    //      $('.mobile-menu').addClass('h-class');
    //   });
  
    //   $(window).scroll(function () {
    //      $('.mobile-menu').removeClass('h-class');
    //      $('.mobile-menu').addClass('h-class');
    //   });

    $('.mobile-menu ul li a').click(function(){
        $(this).find("i").toggleClass("rotate");
    })

    $('.md-btn').click(function(){
        $(this).find("ul").toggleClass("d-class");
    })

    $('.menu_icon').click(function(){
        $('.mobile-menu').toggleClass("h-class");
        return false;
    });

    $('.m-menu-closer').click(function(){
        $('.mobile-menu').toggleClass("h-class");
        return false;
    });

    // Testimonials Carousel
    $('.testimonial-carousel').owlCarousel({
        items:1,
        nav:true,
        navText:['<i class="fa-solid fa-angle-left"></i>','<i class="fa-solid fa-angle-right"></i>'],
        loop:true,
        dots:false,
        autoplay:true
    });

    // Popup Video
    $('#popupVideo').magnificPopup({
        type:'iframe'
    });

    $(window).click(function () {
        $('.mobile-menu-area').removeClass('menu-remove');
        $('.mobile-menu-area').addClass('menu-remove');
     });
  
     $(window).scroll(function () {
        $('.mobile-menu-area').removeClass('menu-remove');
        $('.mobile-menu-area').addClass('menu-remove');
     });
  
     $('.menu-bar').click(function () {
        $('.mobile-menu-area').toggleClass('menu-remove');
        return false;
     });

    //  counterUp 

    $('.countUp').counterUp({
        delay: 10,
        time: 1000
    });

    $('.single-fq').click(function(){
        $(this).find('i').toggleClass('rotate90')
        $(this).find('.fq-des').toggleClass('hide')
    })

    $('#demo').niceSelect();

});